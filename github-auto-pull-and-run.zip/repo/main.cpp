// Simple C++ program to display "Hello World"

// Header file for input output functions
#include<iostream>

using namespace std;

// main function -
// where the execution of program begins
int main()
{
	// prints hello world
	cout<<"Hello World";
	
	return 0;
}
